from django.contrib import admin
from blog_app.models import Post
# Register your models here.
admin.site.register(Post)  # to register post model in the admin pannel