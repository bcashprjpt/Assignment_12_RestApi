import django_filters
from django import forms
from blog_app.models import Post

class PostFilter(django_filters.FilterSet):
    # Use DateTimeFilter to filter by the date part of a DateTimeField
    created_on = django_filters.DateTimeFilter(
        widget=forms.DateInput(attrs={'type': 'date'}),  # This will give a date picker in the form
        lookup_expr="date"  # This ensures we only filter by the date (ignoring the time)
    )

    class Meta:
        model = Post
        fields = ['created_on',]
