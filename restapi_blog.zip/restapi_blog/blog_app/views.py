from django.shortcuts import render
from rest_framework.response import Response
from rest_framework.decorators import APIView
from blog_app.serializers import PostSerializer
from rest_framework.viewsets import ModelViewSet
from blog_app.models import Post
from rest_framework.permissions import IsAuthenticated
from blog_app.permissions import IsPostProcessor
from rest_framework import filters
from blog_app.filters import PostFilter
from django_filters.rest_framework import DjangoFilterBackend
# Create your views here.

class RestApiView(APIView):

      '''
    def get(self,request):
        return Response({'message' : "Hello world how r u"})
        '''

class PostView(ModelViewSet):
    permission_classes = [IsAuthenticated, IsPostProcessor]
    # queryset = Post.objects.all() # his queryset is used to view all the post of admin and other user also
    serializer_class = PostSerializer

    # This below two line is used to implement the filter button and help to filter or search the post by it title or content
    # filter_backends = [filters.SearchFilter]
    # search_fields = ['title', 'content']

    # This  three line of code is used to filter is based on date
    filter_backends = [DjangoFilterBackend , filters.SearchFilter, filters.OrderingFilter]
    filter_class = PostFilter
    ordering_fields = ['id']
    search_fields = ['title', 'content']


    def get_queryset(self): # This method is used to view the post of only individual user created by own
        return Post.objects.filter(created_by = self.request.user)