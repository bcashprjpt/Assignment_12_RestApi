from rest_framework import permissions # this permission class is used to give permission not to view or delete the post by admin

class IsPostProcessor(permissions.BasePermission):

    def has_object_permission(self, request, view, obj):

        if request.method in permissions.SAFE_METHODS: # This method is give only read function to the admin and cannot perform delete operation
            return True


        return obj.created_by == request.user
