from rest_framework import serializers
from blog_app.models import Post
# serializer is used to convert the models into json or html response
class PostSerializer(serializers.ModelSerializer):
    created_by = serializers.CharField( source = "created_by.username", read_only = True)
    class Meta:
        model = Post
        fields = '__all__' # it will display all the fields in the post model to the json or html response
        read_only_fileds = ('created_by')

    def create(self,validated_data):
        validated_data['created_by'] = self.context['request'].user
        return Post.objects.create(**validated_data)